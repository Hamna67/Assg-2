/*a compressor for compressing the file meno.txt using huffman coding*/

import scala.io.Source
import scala.collection.immutable.ListMap
import java.io._
 
object compressor {

 def main(args: Array[String]): Unit = {
    compress()
	
  }
  
  
  def compress(): Unit = {                                                      

	val source = Source.fromFile("meno.1b.txt").getLines.mkString("\n")         /*Reading the text file into a string*/
	val length = source.length  												/*getting the length of source*/
	 
	val count = 1                                                               /*setting initial count equal to 1*/
	val B = Map(source(0) -> 1)                                                 /*making an intial map with the first character of string*/
	


	val map = addMap(count, length, source, B)                               	/*calling add map function to get make a charcter map of the string*/
	
	val sortedMap = ListMap(map.toSeq.sortBy(_._2):_*)                          /*sorting the map by value in ascending order*/
	//printMap(sortedMap)                                                         /*printing the map*/
	
	val tree = new Tree(sortedMap)                                              /*making a tree object and passing the sorted map to it*/
	                                                             
	val binMap = tree.makeMap(tree.makeTree(),sortedMap)						/*calling function for building the binary tree and bin map*/
	val compressed = convert(source,binMap)                                     /*converting the file to first binary string and then to ascii characters*/
			
	
	val file = new File("compressed.txt")                                       /*printing the compressed string to file*/                            
	val bw = new BufferedWriter(new FileWriter(file))
	bw.write(compressed)
	bw.close()
		
	println(compressed)
	
	
	}
	
	
	
	/*function for making a map from the string passed*/
	def addMap(count: Int,total: Int,source: String, m : Map[Char, Int]): Map[Char, Int] =
	{
		if(count == total)                                                      /*if reached the end of file then return the map*/
		{ 
			return m                                                            
		}
		
		else
		{
			/*print(source(count))*/
			val n = m.getOrElse(source(count),null).asInstanceOf[Int]           /*getting the value of key(character at position count)*/
			if(n != 0)                                                          /*if value is not null*/
			{
				/*println(n)*/
				val freq = n + 1                                                /*adding one to the frequency of value as it stores the freq of character*/
				
				val A  = m + (source(count) -> freq)                            /*adding the next character to the passed map*/
				val i = count + 1                                               /*going to the next character*/
				addMap(i, total, source, A)                                     /*calling the function again with the new values*/
				
			}
			
			else
			{
				val A  = m + (source(count) -> 1)                                /* if the value does not already exits, put one in its place*/
				val i = count + 1                                                
				addMap(i, total, source, A)
			}	
			
		}
		
	}
	
	
	
	def printMap(m : Map[Char, Int]): Unit =                                     /*function for printing a map*/
	{
		for ((k,v) <- m) printf("key: %s, value: %s\n", k, v)
	}
	
	
	/*function for getting the binary string for input string using the map passed*/
	def getBin(count: Int,source: String, returnString: String, map: Map[Char, String]) : String =
	{
		if(count == (source.length))                                               /*if count reaches end of string then return string*/
			return returnString
		
	
		else
		{
			val key = source(count)                                             
			val value = map.getOrElse(key,null)                                    /*getting the value against each character*/
			
			getBin(count + 1,source, returnString + value, map)                    /*recursive call to itself*/
			
		}
		
	}
	
	
	/*function for converting the read string to binary string and then to ascii characters*/
	def convert(source: String, map : Map[Char, String]): String = 
	{
		val i = 0
		val binaryString = getBin(i, source, "", map)                               /*getting the binary strin for the input string passed*/
		
		val nfile = new File("binary.txt")                                          /*writing bianry string to file*/
		val nbw = new BufferedWriter(new FileWriter(nfile))
		nbw.write(binaryString)
		nbw.close()
		
		
		val count = 0
		
		val remainder = 7 - (binaryString.length%7)                                 /*appending zeros to make string mulitple of 7*/	
		val appendedString = appendEnd(remainder, binaryString)
		//println(appendedString)
		
		val charString = getCharString(count, appendedString, "")                   /*function getting ascii character for the binary string*/
		/*println(charString)*/
		
		val table = new File("table.txt")                                           /*printing the map containg characters and their binary stirngs to file*/
		val t = new BufferedWriter(new FileWriter(table))
		for ((k,v) <- map) 
		{
			t.write(v + "xxx" + k+ "*")
		}
		t.close()
	
		return charString + remainder                                                          /*returing the converted string*/
	}
	
	
	
	
	/*function for appending to the binary string in order to make lenght mulitple of 7*/
	def appendEnd(rem: Int, binaryString: String) : String =
	{
			if(rem == 0)                                                                    /*if remainder becomes zero retrun the string*/
				return binaryString
				
			return appendEnd(rem - 1, binaryString + '0')                                   /*append char '0' to the string and decrement rem*/
	}
	
	/*function for getting ascii for the binray string*/
	def getCharString(count: Int, binaryString: String, returnString: String) : String =
	{
		if(count == (binaryString.length))                                                  /*if length of the binString has reached return*/
			return returnString
		
	
		else
		{
			val x = Integer.parseInt(binaryString.substring(count,count+7),2)               /*taking substring of 7 and converting into int*/
			val c = (x).asInstanceOf[Char]                                                  /*converting the int to char(ascii)*/
			
			//print(x + "         ")
			//println(x + " : "+ c)
			
			getCharString(count + 7,binaryString,returnString + c)                          /*calling the function again with appended return string and next count*/
		
		}
		
	}
	
	
	
	/*class for node*/
	class Node(val leaf: Char, val data: Int, val left : Node, val right : Node)  {}        /*class node has left node, right node, a char and an int*/
	
	
	
	/*class for binary tree*/
	class Tree(val m :  Map[Char, Int])
	{
		/*functiona for making the bianry tree*/
		def makeTree(): Node = 
		{
			val nodeList : List[Node] = makeList()                                          /*calling makeList for converting the passed(to class) to list of nodes*/
			val treeList : List[Node] = addNode(nodeList)                                   /*add node is called for constructing the tree*/
			return treeList(0)
		}
		
		/*function for making a list having node as each element, the passed map is converted into it*/
		def makeList(): List[Node] = 
		{
			val list = m.toList
			val nodeList: List[Node] = list.map{case (x : Char, y : Int) => new Node(x : Char, y : Int,null,null)}
			return nodeList	
		}
		
		
		/*function called by makeTree to add the nodes in the process of making the binary tree*/
		def addNode(nodeList: List[Node]): List[Node] =
		{
			if(nodeList.length == 1)
				{return nodeList}
			else
			{
				val first : Node = nodeList(0)                                                      /*getting the first list elem*/
				val second : Node = nodeList(1)                                                     /*getting the second list elem*/
				val newNode : Node = new Node(0.toChar, (first.data + second.data), first, second)  /*making the new node by adding the smallest freq nodes*/
				val subList1 : List[Node] = remove(first, nodeList)                                 /*removing the first node*/
				val subList2 : List[Node] = remove(second, subList1)                                /*removing the second node*/
				val newList : List[Node] = newNode :: subList2                                      /*adding the new node*/
				newList.sortWith(_.data<_.data)                                                     /*sorting the new list in ascending order*/
				addNode(newList)                                                                    /*recursive call to itself*/
			}
		}


		
		def remove(node: Node, list: List[Node]) = list diff List(node)                             /*function for removing an elem from list*/

		

		def printTree(root : Node) : Unit =                                                         /*function for printing the binary tree*/
		{
			println("Root: " + root.data)
			
			if(root.left != null)																    /*if the root has a left node*/    
			{
				printTree(root.left)
			}
			
			if(root.right != null)    		                                                        /*if the root has a right node*/  
			{
				printTree(root.right)
			}
			
			else
			{
				println("Leaf: " + root.leaf)
			}
		}
		
		def makeMap(node : Node, m : Map[Char, Int]): Map[Char, String] =                          /*function for making a binary map for characters*/
		{
			val newMap = m map {case(k, v) => (k -> (getBinString(k,"",node).replace("*", "")))}   /*for each element of the passed map, get a binary string and store in new map*/
			/*for ((k,v) <- newMap) printf("key: %s, value: %s\n", k, v)*/
			return newMap
		}
		
		
		
		def getBinString(c: Char, bin : String, root : Node) : String =                            /*function for getting a string from the binary tree for a given character*/
		{
			
			if((root.leaf == c))                                                                   /*if the character is found*/
			{		
				return "*" + bin                                                                   /*return * plus the character*/
			}
			
			if(root.left != null)                                                                  /*if the root has a left node*/                      
			{
				val x = getBinString(c, bin + "1", root.left)
				if (x(0) == '*')                                                                   /*if the returned string has * then return it*/
					return x;	
			}
			
			if(root.right != null)                                                                 /*if the root has a right node*/  
			{
				val x = getBinString(c, bin + "0", root.right)
				if (x(0) == '*')
					return x;
			}
			
			return bin		
			
		}
		
		
	}
		
}







