import scala.io.Source

object test
{
def main(args: Array[String]): Unit = {
    
	println("TEST # 1 :  " + checkBinary())
	println("TEST # 2 :  " + checkOutput())
	
  }
  
  
  
  /*test for checking if the huffman conversion of both to binary is same*/
  def checkBinary(): String =
  {
	val compressed = Source.fromFile("binary.txt").getLines.mkString("\n") 
	val decompressed = Source.fromFile("binOut.txt").getLines.mkString("\n") 
	
	if(compressed.matches(decompressed))
		return "Passed"
	else
		return "Failed"
  }
  
  
  
  /*test for checking if the original file and the decompressed files are same*/
  def checkOutput(): String =
  {
	val original = Source.fromFile("meno.1b.txt").getLines.mkString("\n") 
	val decompressed = Source.fromFile("decompressed.txt").getLines.mkString("\n") 
	
	var count = 0
	var check = 0
	
	for (count <- 0 to original.length-1)
	{
		if(original(count) == decompressed(count))
		{	
			check = 1
		}
		else 
		{
			check = 0
		}
	}
	
	if(check == 1)
		return "Passed"
	else
		return "Failed"
		
  }
}





