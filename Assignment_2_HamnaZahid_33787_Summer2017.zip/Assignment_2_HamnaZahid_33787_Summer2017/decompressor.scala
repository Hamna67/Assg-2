import scala.io.Source
import scala.collection.immutable.ListMap
import java.io._

object decompressor {

 def main(args: Array[String]): Unit = {
    decompress()
	
  }
	
	/*function for decomperssing the file*/
	def decompress(): Unit =
	{
		val table = Source.fromFile("table.txt").getLines.mkString("\n")            /*Reading the symbol table from text file into a string*/
		//println(table)
		val x = table.split("\\*")                                                  /*splitting the table tuple by tuple by using * */	
		val m = Map("0" -> 'a')                                                     /*creating an empty map*/
		val binMap = getMap(0,x,m)                                                  /*calling function get map to construct map from the read symbol table*/
		
		
		val source = Source.fromFile("compressed.txt").getLines.mkString("\n")      /*Reading compressed string from the text file into a string*/
		val i = 0
		val drop = Integer.parseInt("0" + source((source.length)-1))
		val bytes = (getBytes(i, source.substring(0,(source.length)-1), "")).dropRight(drop)                          /*converting the read compressed string to string bytes*/
		//println(bytes)
		
		
		val bfile = new File("binOut.txt")                                          /*writing the converted bytes to an text file*/
		val bbw = new BufferedWriter(new FileWriter(bfile))
		bbw.write(bytes)
		bbw.close()
		
		
		val decompressed = getOriginalString(i,i+1, bytes, "", binMap)              /*getting the decompressed string by passing the byte sting and binMap to a function*/                     
		
		
		val file = new File("decompressed.txt")                                     /*storing the decompressed string to a file*/
		val bw = new BufferedWriter(new FileWriter(file))
		bw.write(decompressed)
		bw.close()
		println(decompressed)		
	}
	
	
	/*function for making a map from the read symbol table*/
	def getMap(count: Int, a: Array[String],map: Map[String, Char]) :  Map[String, Char] = 
	{
		if(count == a.length)
			return map
		else
		{
			val temp = a(count).split("xxx")                                         /*splitting each touple by xxx */
			//println(temp(0) +" : "+ (temp(1))(0))
			val m : Map[String, Char]= map + (temp(0) -> (temp(1))(0))               /*mapping the touples to a map*/
			getMap(count + 1, a, m)                                                  /*recursive call*/
		}
	}
	
	
	/*function for getting original string given the binary string and binMap*/
	def getOriginalString(count: Int, next: Int,binaryString: String, returnString: String, map: Map[String, Char]) : String =
	{
		if(next >= (binaryString.length + 1))                                         /*if our counter goes out of length return the string*/            
			return returnString
		
	
		else
		{
			val key = binaryString.substring(count,next)                              /*getting character value for the binary substring starting at count and ending at next -1 */
			//println(key)
			if(map.contains(key))                                                     /*if map contains the key*/
			{
				val value = map.getOrElse(key,null)                                   /*get the value and return it*/
				//print(value +" : " + key)
				getOriginalString(next,next + 1, binaryString, returnString + value, map)
				
			}
			else
			{
				getOriginalString(count,next + 1,binaryString, returnString, map)     /*esle return without appending it*/
			}
		}
		
	}
	
	/*function for returning bytes*/
	def getBytes(count: Int, source: String,returnString: String) : String =
	{
		if(count == (source.length))
			return returnString
			
		else
		{
			val b = source(count).toInt                                                /*getting the int of read character*/                                 
			//print(b + "    ")
			val num :String = Integer.toBinaryString(b)                                /*converting it to a binary string*/
			val remainder = 7 - (num.length%7)                                         /*if it is not a mulitple of of 7, then making it*/                        
			val x = appendStart(remainder, num)                                        /*by appending 0 at start*/
			val n = x.substring(x.length-7,x.length)                                   /*getting only the last 7 char*/
			/*println(n)*/
			getBytes(count + 1, source, returnString + n)                              /*recursive call*/
		}
	
	}
	
	/*function for appending to the binary string in order to make lenght mulitple of 7*/
	def appendStart(rem: Int, binaryString: String) : String =
	{
			if(rem == 0)
				return binaryString
				
			return appendStart(rem - 1, '0' + binaryString )
	}
	
	
  
}
